﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_TimeZoneinformation
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Working with Time Zone in C#");

            Console.WriteLine("Currently selected time Zone in my system is {0}\n",TimeZoneInfo.Local.DisplayName);

            var Zones = TimeZoneInfo.GetSystemTimeZones();
            foreach (var Zone in Zones)
            {
                Console.WriteLine(Zone.DisplayName);
            }
        }
    }
}
