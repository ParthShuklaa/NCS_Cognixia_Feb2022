﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Strings
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Working with String in C#");
            string name = "Niel Armstrong ";
            string country = " USA ";
            Console.WriteLine("Length of name is :"+name.Length);
            Console.WriteLine("Name in Upper Case: " + name.ToUpper());
            Console.WriteLine("Name in LowerCase: "+name.ToLower());
            string result = name + country;
            Console.WriteLine(result);
            string newResult = string.Concat(name, country);
            Console.WriteLine(newResult);
            //string Interpolation 
            string nameString = $"Name  of the person is :{name} {country}";
            Console.WriteLine(nameString);
            //Accessing string via Index[] 
            Console.WriteLine(nameString[0]);
            //Finding the index position of a specific character in string
            Console.WriteLine(nameString.IndexOf("U"));
            Console.WriteLine(nameString.Substring(30));
            // How to Extract a Substring "Niel Armstrong USA" from Main String stored in nameString 
            int charPos = nameString.IndexOf("N");
            Console.WriteLine(nameString.Substring(charPos));
        }
    }
}
