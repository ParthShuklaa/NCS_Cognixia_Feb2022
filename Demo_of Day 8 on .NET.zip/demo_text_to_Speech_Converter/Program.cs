﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Speech.Synthesis;

namespace demo_text_to_Speech_Converter
{
    class Program
    {
        static void Main(string[] args)
        {
            //Step1:Import package that will convert text to speech (gtts:google text to speec converter)
            /*
             * Step2 : Creating an object of Speech 
             * Step3 : Set Output to default audio device
             * Step4 : Speak()
             */
            Console.WriteLine("Demo on text to Speech Synthesizer" );

            Console.WriteLine("Enter your text");
            string msg = Console.ReadLine();

            SpeechSynthesizer spk = new SpeechSynthesizer();
            spk.SetOutputToDefaultAudioDevice();
            spk.SelectVoice("Microsoft Zira Desktop");// For Selecting Female Voice 
            spk.Speak(msg);

            //To get Details of All Installed Voices in System 
            var Synthesizer = new SpeechSynthesizer();

            //Console.WriteLine(Synthesizer.GetInstalledVoices());

            foreach ( var voice in Synthesizer.GetInstalledVoices())
            {
                var info = voice.VoiceInfo;
                Console.WriteLine($"ID:{info.Id} | Name: {info.Name}| Age:{info.Age}| Gender: {info.Gender}|Culture:{info.Culture}");

            }

            Console.ReadKey();

        }
    }
}
