﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEMO_Entity_Data_Model_DatabaseFirst_Approach
{
    class Program
    {
        static void Main(string[] args)
        {
            //here We will define entities and relationship between them

        }
    }
}
