﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;//Added for Creating SQL Connection object 
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;

namespace Demo_ADOConnectivity
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            //Step1 : Creating a Connection with Connection String of Database
            SqlConnection connection;
            connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=NCS2020;Integrated Security=True");
            connection.Open();
            //Step2 : Creating  Command Object (We Need this For running SQL Statement
            SqlCommand command;
            command = new SqlCommand("SELECT * FROM AGENTS", connection);

            
            //Step3:Creating Data reader Object for running and Displaying Command Object
            SqlDataReader dr;//Reader will Help us in reading Content returned by Command.ExecureReader()
            dr = command.ExecuteReader(); //For Executing Command 
            DataTable dt = new DataTable();
            dt.Load(dr);

            //Step4: Loading Content to Datagrid control on our form
            dataGridView1.DataSource = dt;
            connection.Close();
            


        
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //What Are the Steps for INserting Record in Database 
            //Creating a Command with INSERT Operation
            SqlConnection connection;
            connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=NCS2020;Integrated Security=True");
            connection.Open();
            Insertcommmand = new SqlCommand("INSERT INTO AGENTS VALUES", connection);
            Insertcommand. 
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //DataView dv = new DataView(dt);
            //dv.RowFilter = " ";
            //datGridView1.DatSource = dv;
        }
    }
}
