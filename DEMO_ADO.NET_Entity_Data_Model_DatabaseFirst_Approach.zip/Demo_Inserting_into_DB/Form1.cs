﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demo_Inserting_into_DB
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Step1: Opening Connenction
            //Step2: Creating and Executing Command
            //Step3: Create Data Reader Object 
            //Step4: Closing Connection

            SqlConnection Conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=NCS2020;Integrated Security=True");
            Conn.Open();

            //SqlCommand comm = new SqlCommand("INSERT INTO AGENTS VALUES ('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "'," + textBox4.Text + ",'" + textBox5.Text + "','" + textBox6.Text + "')", Conn);


            //SqlCommand Command = new SqlCommand("INSERT INTO AGENTS VALUES(" +textBox1.Text+ "," +textBox2.Text+ "," +textBox3.Text+ "," +textBox4.Text+ "," +textBox5.Text+ "," +textBox6.Text+ ")", Conn);
            // SqlCommand Command = new SqlCommand("INSERT INTO AGENTS"+"(AGENT_CODE,AGENT_NAME,WORKING_AREA,COMMISSION,PHONE_NO,COUNTRY)"+" VALUES ('07','JAMES BOND','LONDON','.4','1122334455','UK')", Conn); 
            SqlCommand comm = new SqlCommand("INSERT INTO AGENTS VALUES( '" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + textBox6.Text + "')", Conn);

         comm.ExecuteNonQuery();
            //button1.Text = Status.ToString();
            Conn.Close();



         
       
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'nCS2020DataSet.AGENTS' table. You can move, or remove it, as needed.
            this.aGENTSTableAdapter.Fill(this.nCS2020DataSet.AGENTS);
            // TODO: This line of code loads data into the 'nCS2020DataSet.Actor' table. You can move, or remove it, as needed.
            this.actorTableAdapter.Fill(this.nCS2020DataSet.Actor);

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //textBox1.Text = "Cliking on Text1";
        }
    }
}
