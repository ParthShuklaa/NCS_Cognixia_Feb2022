﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DemoEntity_Framework
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            NCS2020Entities db = new NCS2020Entities();
            AGENT MyAgent = new AGENT();

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        public void ClearData()
        {
            textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = textBox5.Text = textBox6.Text = string.Empty;
            button2.Enabled = false;
            button1.Text = "Save";

        }

        public void SetDataInGridView()
        {
            NCS2020Entities db = new NCS2020Entities();
            dataGridView1.AutoGenerateColumns = false;//This Will Disable Automatic genration of Columns
            dataGridView1.DataSource = db.AGENTS.ToList<AGENT>();
            //We have Set AutoGenrated Column to False  as wer are defining our own Custom Column
            //and Next getdata from Agent table  and Seeting it in grid view as data Source  
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            AGENT MyAgent = new AGENT(); // Created an Object of table Class 
            MyAgent.AGENT_CODE = "00701";
            MyAgent.AGENT_NAME = "AQUAMAN";
            MyAgent.COMMISSION = ".50";
            MyAgent.COUNTRY = "JAPAN";
            MyAgent.WORKING_AREA = "Mt FUJI";
            MyAgent.PHONE_NO = "9999222244";

            //Creating object of Connection String 
           
            ClearData();
            SetDataInGridView();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AGENT MyAgent = new AGENT(); // Created an Object of table Class 
            MyAgent.AGENT_CODE = textBox1.Text.Trim();
            MyAgent.AGENT_NAME = textBox2.Text.Trim();
            MyAgent.COMMISSION = textBox3.Text.Trim();
            MyAgent.COUNTRY = textBox4.Text.Trim();
            MyAgent.WORKING_AREA = textBox5.Text.Trim();
            MyAgent.PHONE_NO = textBox6.Text.Trim();

            NCS2020Entities db = new NCS2020Entities();//Creating Object of DataBAse 
            db.AGENTS.Add(MyAgent);
            db.SaveChanges();// Defined in DB Object Class 
            SetDataInGridView();
            MessageBox.Show("Reords are Saved Sucessfully...!!!");
            //Here We are setting data in thr Agent Model oBject fro the textBox
            //We Are Saving changes using Save Changes
            //

        }
    }
}
