﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Array_in_CSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Working with Array in C#");

            //Step1: 1:Declaring Array 
            //Step2: Displaying Content 

            string[] cars = { "BMW", "Mercedes", "TESLA", "Ford" };
            for (int i = 0; i < cars.Length; i++)
            {
                Console.WriteLine(cars[i]);
            }

            //Changing elelement in an Array
            cars[3] = "Volvo";

            for (int i = 0; i < cars.Length; i++)
            {
                Console.WriteLine(cars[i]);
            }

            //We Can use Foreach in any collection : it can be an array

            foreach (var mycar in cars)
            {
                Console.WriteLine(mycar);
            }

            //Sorting elelments of array
            Console.WriteLine("Sorting elements in Array");
            Array.Sort(cars);
            foreach (var car in cars)
            {
                Console.WriteLine(car);
            }

            //Different way of initilizing Array 

            string[] myTVShows = new string[4];
            myTVShows[0] = Console.ReadLine();//Asking user to provide vlaue 
            Console.WriteLine(myTVShows[0]);
            //2:Creating array with fixed Size 
            string[] myMovies = new string[5] { "Intersteller", "Spiderman", "Titanic", "Avengers", "Jurassic park" };
            Console.WriteLine("Displaying Content of Movies Array " + myMovies);//Can not be used to display content of an array
            //3:Creating array withour specifying the size 
            string[] mySports = new string[] { "Chess", "Snooker", "Cricket", "Football", "Hockey" };
            Console.WriteLine("Total Size of my My Sports Array is: "+mySports.Length);
            Console.WriteLine(  "Rank of My Sports Array is: "+mySports.Rank);
            //4: Crarting an Array of Elements withour new keyword
            string[] myColors = { "Cyan", "Azure", "Crimson" };
            foreach (var color in myColors)
            {
                Console.WriteLine(color);
            }

            //We can declare an Array first andcan provide values to it later 
            string[] mylaptops;

            //using new is mandatory  while adding values to array
            mylaptops = new string[] { "Dell", "Lenovo", "Acer", "Toshiba" };

        }
    }
}
