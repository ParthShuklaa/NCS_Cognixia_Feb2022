﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_DoWhile_While_loop
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Difference between While and Do While loop");

            int i = 0;
            while (i==0)
                Console.WriteLine(" i is 10");

            {
                Console.WriteLine(i);
                i++;
            }


            
            Console.WriteLine("lets se how do while loops work");
            int j = 10;
            do
            {
              
                Console.WriteLine("This message is coming from Do part of do while loop");
                j--;
            } while (j>0);
        }
    }
}
