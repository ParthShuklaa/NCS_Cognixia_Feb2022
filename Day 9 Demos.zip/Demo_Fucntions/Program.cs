﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Fucntions
{
    class Program
    {
        //static int Add(int a, int b)
        //{
        //    return a + b;
        //}
       static  void DisplayMessage(string Fname = "Julia")
        {
            Console.WriteLine(Fname+"Good Morning");
        }

        static int Add(int x , int y) //This Function accepts int as argument 
        {
            return x + y;
        }
        static double Add(double x, double y)//This function accepts double value as argument 
        {
            return x + y;
        }

        static  string Add(string x, string y)//this functions string as argument 
        {
            return x + y;
        }

        static void Main(string[] args)
        {
            DisplayMessage("John");
            DisplayMessage("Liam");
            DisplayMessage("Peter");
            DisplayMessage();// Default name will be displayed 
            

            int num1 = Add(10, 5);
            double num2 = Add(101.4d, 10.8d);
            string msg = Add("Good", "Morning");
            Console.WriteLine("Value for num1"+num1);
            Console.WriteLine("Value for num2"+num2);
            Console.WriteLine("Value for msg:"+msg);

            Console.WriteLine("creating an object of Student class");
            Student firstyear = new Student();
            firstyear.display("James", "Bond");
            Student Secondyear = new Student();
            Secondyear.display("Captain", "America");


        }
    }
}
