﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Fucntions
{
    class Student
    {
        string Fname;
        string Lname;
        int age;
       public void display(string fname,string lname)
        {
            this.Fname = fname;//this keyword is helping in pointing towards the current instance of the class 
            this.Lname = lname;
            Console.WriteLine(Fname+"-"+Lname);

        }
        
    }
}
