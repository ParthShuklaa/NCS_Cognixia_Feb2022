﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Value_Ref_Memory_Implementation
{
    class Program
    {
        static void Main(string[] args)//Prgram execution starts from main()
        {
            Console.WriteLine("Memory implementation for value and reference types in C#");
            int v1 = 12;//value Types 
            int v2 = 22;
            v1 = v2;//Both v1 and V2 will be on the stack  and are different entities 
            Console.WriteLine(v2);
            Console.WriteLine(v1);
            v2 = 101;
            Console.WriteLine("Lets check values after changing v2..");
            Console.WriteLine(v1);
            Console.WriteLine(v2);

            //lets create a ref types 
            A obj1 = new A(12);
            A obj2 = new A(22);
            obj2 = obj1;//Both variables are on heap as two enties 
           
            Console.WriteLine(obj2.value);
            Console.WriteLine(obj1.value);
            //obj1.value = 51;
            A obj3 = new A(100);
            obj2.value = 101;
            obj3.value = 51;
            Console.WriteLine("Values after new Assignment are");
            Console.WriteLine(obj2.value);
            Console.WriteLine(obj1.value);
            Console.WriteLine(obj3.value);
            Console.Read();

        }
    }
    class A // class is a keyword 
    {
        public int value { get; set; } //DataMember
        public A(int passbyref)   //Special Member Function- Contructor
        {
            this.value = passbyref;
        }
    }
}
