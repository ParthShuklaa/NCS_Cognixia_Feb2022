﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Switch
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(" Displaying name of the Day depending upon Number entered from 1-7 by the user");


            // Ask user to enter no from above range
            int day = Convert.ToInt32(Console.ReadLine());
            //Implementing Switch
            switch (day)
            {
                case 1:
                    Console.WriteLine("Monday");
                    break;
                case 2:
                    Console.WriteLine("Tuesday");
                    break;

                case 3:
                    Console.WriteLine("Wednesday");
                    break;
                case 4:
                    Console.WriteLine("Thursday");
                    break;
                case 5:
                    Console.WriteLine("Friday");
                    break;
                case 6:
                    Console.WriteLine("Saturday - It's a Week End");
                    break;
                case 7:
                    Console.WriteLine("Sunday -  Enjoy your Week End Break...");
                    break;

                default:
                    Console.WriteLine("make Sure You have entered value in between 1-7, try again ");
                    break;
            }
        }
    }
}
