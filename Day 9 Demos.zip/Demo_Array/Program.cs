﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
//using System.Threading;

namespace Demo_Array
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Understanding Continue Keyword in C#");
            for (int i = 5; i < 10; i++)
            {
                if (i == 5)
                {
                    Console.WriteLine("5 is there in the list");
                    continue;
                }
                Console.WriteLine(i);
            }

            //Console.WriteLine("Displaying elemement in reverse order");
            for (int i = 10; i > 0; i--)
            {
                Console.WriteLine(i);
            }

            for (int i = 0; i < 50; i++)
            {

                Console.WriteLine(DateTime.Now);
                Thread.Sleep(1000);
            }
        }
    }
}
