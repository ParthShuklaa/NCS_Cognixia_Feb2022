﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoBooleanDatype
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine(  "How to Work with Boolean Datatype");
            bool doneWithBreakfast = true;
            bool resting = true;
            if (doneWithBreakfast && resting)
            {
                Console.WriteLine("Take Rest");
            }
            else
            {
                Console.WriteLine("prepare one and take rest ASAP..");
            }
            Console.WriteLine(doneWithBreakfast);
        }
    }
}
