﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Visivility_Scope
{
    class Car : Vehicle
    {
      private string name = "BMW";//field
      int modelNo = 2021;
      public int Display()
        {
            return modelNo;
        }
        public string Name//property
        {
            get { return name; } //get method
            set { name = value; }//set method
        }

        public int ModelNo { get; set; }
        class Program : Car
    {
            static void Main(string[] args)
            {

                Car obj1 = new Car();
                Console.WriteLine(obj1.name);
                Console.WriteLine(obj1.Display());
                Car obj2 = new Car();
                obj2.Name = "Audi";
                Console.WriteLine(obj2.Name);
                obj2.ModelNo = 2022;
                Console.WriteLine(obj2.ModelNo);
                obj1.HornSound();
                Console.WriteLine(obj1.enginetype);
                Program obj3 = new Program();
                obj3.HornSound();
            }     
        }
    }
}
