﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Visivility_Scope
{
     class Vehicle//base class(parent) 
    {
        public string enginetype ="Hybrid";
        internal void HornSound()
        {
            Console.WriteLine("Ppppppp....pppppppp");
        }
    }
}
