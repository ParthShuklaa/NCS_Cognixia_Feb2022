﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_AppendingText_Into_File
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Appending text to An existing File in C#");
            //Creating a string 
            string myFile = @"file.txt";

            //Appending the textstring
            using (StreamWriter sw = File.AppendText(myFile))
            {
                sw.WriteLine("Debugging is an Art");
                sw.WriteLine("Every programmer is an Artist");

            }

            //reading file content till end of string 
            using (StreamReader sr = File.OpenText(myFile))
            {
                string s = "";//initializing string 
                while ((s = sr.ReadLine()) != null)//Reading content using stream reader object till null(EOF) is encountered  
                {
                    Console.WriteLine(s);
                }
            }
            //displaying last write time of the file 
            DateTime dt = File.GetLastWriteTimeUtc(myFile);
            Console.WriteLine("The Last write time in UTC  for the file was {0}",dt);
        }
    }
}
