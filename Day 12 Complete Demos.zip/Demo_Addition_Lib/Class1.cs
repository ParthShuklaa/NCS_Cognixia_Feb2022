﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Addition_Lib
{
    public class Class1
    {
        public void Display()
        {
            Console.WriteLine("This is Display method");
        }

    }
    class Student
    {
        public string name { get; set; }
        public int Age { get; set; }
    }
}
