﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Demo_ReadingDLL_using_Reflection
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(  "Reading DLL File Using Reflection");
             Assembly SampleAssembly = Assembly.LoadFrom(@"C:\Users\DELL\Documents\.NET Full Stack Feb 2022\C#.NET\Day 12 Demos\Demo_Addition_Lib\bin\Debug\Demo_Addition_Lib.dll");
            Type[] types = SampleAssembly.GetTypes();
            //Obtain a ref to a method known to exist in assembly
            foreach (var item in types)
            {
                Console.WriteLine("Class : {0}", item.Name);

                MethodInfo[] methods = item.GetMethods();
                //Array to Store Methods
                foreach (var method in methods)
                {
                    Console.WriteLine("-------->Methods : {0}", method.Name);

                    //Array to store paramaters
                    ParameterInfo[] parameters = method.GetParameters();
                    foreach (var arg in parameters)
                    {
                        Console.WriteLine("-------------Parameters :" +
                            " {0} Type :{1}", arg.Name, arg.ParameterType);
                    }
                }
            }

                //Obtain a ref to parameters info collection
            //    ParameterInfo[] Params = Method.GetParameters();
            //foreach (ParameterInfo Param in Params)
            //{
            //    Console.WriteLine("Param ="+Param.Name.ToString());
            //    Console.WriteLine("Type =" +Param.ParameterType.ToString());
            //    Console.WriteLine("Position ="+Param.Position.ToString());
            //    Console.WriteLine("Optional ="+Param.IsOptional.ToString());
            //}
        
        }
    }
}
