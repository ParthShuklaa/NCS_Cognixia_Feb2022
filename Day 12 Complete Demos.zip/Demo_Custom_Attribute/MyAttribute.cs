﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Custom_Attribute
{/*
  * 
Step1 :Using the AttributeUsageAttribute 
Stpe2 :Defining the Attribute class  
Step3 :Defining Constructor and Properties  
  */
    [AttributeUsage(AttributeTargets.All)]
     internal class MyAttribute :Attribute
    {
        private string name;
        private string actions;
        public MyAttribute(string name, string actions)
        {
            this.name = name;
            this.actions = actions;
        }

        public string Name { get; }
        public string Action { get; }
    }
}
