﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Custom_Attribute
{
    class Program
    {
        static void Main(string[] args)
        {
            Student obj1 = new Student();
            obj1.setDetails(7,"James Bond", 99.5);
            Console.WriteLine("Student Details...!! ");
            Console.WriteLine("Roll Number :{0} ",obj1.rollNumber());
            Console.WriteLine("Name is :{0}", obj1.sName());
            Console.WriteLine("Marks is :{0}",obj1.getmarks());
        }
    }
}
