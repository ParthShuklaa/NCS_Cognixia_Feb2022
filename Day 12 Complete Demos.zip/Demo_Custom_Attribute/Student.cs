﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Custom_Attribute
{
    class Student
    {
        //Private fields
        private int rollNo;
        private string stuName;
        private double marks;

        [MyAttribute("Modifier", "Assign the Student Details")]
        public void setDetails(int r, string sn, double m)
        {
            rollNo = r;
            stuName = sn;
            marks = m;
        }
        [MyAttribute("Acessor", "Returns value of RollNo")]
        public int rollNumber()
        {
            return rollNo;
        }

        [MyAttribute("Accessor", "Returns value of Student Name")]
        public string sName()
        {
            return stuName;
        }

        [MyAttribute("Accesor", " Returns value of Marks ")]
        public double getmarks()
        {
            return marks;
        }
    }
}
