﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Demo_FileHandlinging_CSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("File handling in C#");
            //Step1: Creating a text String 
            string myText = "problem Solving is a Skill that can be mastered using programming";

            //Step2: Creating a File to Save MyText
            File.WriteAllText("SampleFile.txt", myText);

            //Step3: Reading content of the file 
            string readText = File.ReadAllText("SampleFile.txt");

            //Step4: Displaying content of the file 
            Console.WriteLine(readText);
            Console.WriteLine("Following is the output of the file ead Operation ...!!!!");
            //File.ReadAllText() - Can also be used for reading file
            StreamReader sr = new StreamReader(@"C:\Users\DELL\Documents\.NET Full Stack Feb 2022\C#.NET\Day 12 Demos\Demo_FileHandlinging_CSharp\bin\Debug\SampleFile.txt");
            Console.WriteLine(sr.ReadLine());
        }
    }
}
