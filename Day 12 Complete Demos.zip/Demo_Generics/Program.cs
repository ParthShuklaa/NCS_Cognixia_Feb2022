﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Generics
{
    //DataStore is a generic Class. T is a Type Parameter ( Fields, Properties, return type and
    //delegate inside  Datastore Class
    class DataStore<T>
    {
        public T Data { get; set; }//Generic Type Property
        public T[] myarray = new T [10]; // We can have generic Array
    }

    //We Can also define Multiple type parameter seprated by Comma
    class KeyValuepair<Tkey,TValue>
    {
        public Tkey Key { get; set; }
        public TValue Value { get; set; }

    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Implementing Generics in C# ");
            //Creating an Object of type String 
            DataStore<string> store = new DataStore<string>();
            store.Data = "Welcome to our Store in Singapore.!!!!";
            Console.WriteLine("Here is the message from store {0}",store.Data);

            
            //here we are ceating an object of type int so that we can store integer value 
            DataStore<int> storeNo = new DataStore<int>();
            storeNo.Data = 101;
            Console.WriteLine("here is the Store No :{0}", storeNo.Data);

            //store.Data = 12345; This will give us compile time error


            KeyValuepair<int, string> facebook = new KeyValuepair<int, string>();//Creating Object with <int,string>
            facebook.Key = 101;
            facebook.Value = "QWERTY";
            Console.WriteLine(facebook.Key + facebook.Value);

            KeyValuepair<string, string> twitter = new KeyValuepair<string, string>();//Creating Object with string,string
            twitter.Key = "asdfg";
            twitter.Value = "qazwsxedc";
            Console.WriteLine(twitter.Key+":"+twitter.Value);


        }
    }
}
