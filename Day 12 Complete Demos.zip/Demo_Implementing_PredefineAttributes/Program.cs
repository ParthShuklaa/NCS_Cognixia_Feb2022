﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Implementing_PredefineAttributes
{
    class Program
    {
        //Meta Data Extension for giving addiotnal information to compiler 
        //Can be used to impose a condition or for increasing efficiency of code
        [Obsolete("This Method is Obsolete and should not be used ",false)]
        public static void DemoMethod()
        {
            Console.WriteLine("Hi There, I am right now in Display Method....!!!");
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Implementing Predefine Atributes in C#");
            DemoMethod();

        }
    }
}
