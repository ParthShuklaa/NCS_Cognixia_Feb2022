﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace Demo_Reflection
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Reflection : a Way to describe meta data of Types, method and fields in the code.");

            Type mytype = typeof(string);
            //Initilizing mytype as type of string


            //use Reflection to find out if any day data is related to given type
            Console.WriteLine("Name : {0}",mytype.Name);
            Console.WriteLine("Full name : {0}", mytype.FullName);
            Console.WriteLine("NameSpace : {0}",mytype.Namespace);
            Console.WriteLine("BaseTypes : {0}",mytype.BaseType);

            /*Step 1: Declaring Instance of an Assembly 
             *Step 2: Call the getExecutingAssebly Method
             *Step 3: Loading the current Assembly 
             */
            Assembly executing = Assembly.GetExecutingAssembly();


            //Array to store types of the current Assembly 
            Type[] types = executing.GetTypes();
            foreach (var item in types)
            {
                Console.WriteLine("Class : {0}",item.Name);

                MethodInfo[] methods = item.GetMethods();
                
                //Array to Store Methods
                foreach (var method in methods )
                {
                    Console.WriteLine("-------->Methods : {0}", method.Name);

                    //Array to store paramaters
                    ParameterInfo[] parameters = method.GetParameters();
                    foreach (var arg in parameters)
                    {
                        Console.WriteLine("-------------Parameters :" +
                            " {0} Type :{1}",arg.Name , arg.ParameterType);
                    }
                }
            }

        }
    }
}
