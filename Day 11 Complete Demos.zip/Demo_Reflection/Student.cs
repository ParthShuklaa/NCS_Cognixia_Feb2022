﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Reflection
{
    class Employee
    { }
    class Student
    {
        public int RollNo { get; set; }
        public string Name { get; set; }


        //No Argument Constructor 
        public Student()
        {
            RollNo = 0;
            Name = String.Empty;
        }
        //Paramatrised Constructor 
        public Student (int Rno , string name)
        {
            RollNo = Rno;
            Name = name;

        }

        public void DisplayData()
        {
            Console.WriteLine("Roll Number : {0}",RollNo);
            Console.WriteLine("Name : {0}",Name);
        }
    }
}
