﻿using System;
using System.Threading;
using System.Threading.Tasks;


namespace Demo_Parallel_Programming_Model
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("C# For Loop... ");
            int number = 10;
            for (int count = 0; count < number; count++)
            {
                //Thread.CurrentThread<managedThreadID - This Will Return
                //an integer  representing Unique
                //identifier for current managend Thread
                Console.WriteLine($" value of Count = {count}, thread = "+
                    $"{Thread.CurrentThread.ManagedThreadId}");
                 Thread.Sleep(10);
            }
            Console.WriteLine();
            Console.WriteLine("Parallel For Loop in C#...");
            Parallel.For(0,number,count => 
            {
             Console.WriteLine($"Value of Count  = {count}, thread = " +
                 $"{Thread.CurrentThread.ManagedThreadId}");
             Thread.Sleep(10);
            });
        }
    }
}
