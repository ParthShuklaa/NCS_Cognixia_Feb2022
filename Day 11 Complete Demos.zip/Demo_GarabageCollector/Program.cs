﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_GarabageCollector
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine( "The Number of generations are "+GC.MaxGeneration);

            Program MyObj1 = new Program();
            Console.WriteLine("The genration Number of Object is : "+ GC.GetGeneration(MyObj1));
            Console.WriteLine("Total Memory:"+GC.GetTotalMemory(false));
            Program MyObj2 = new Program();
            Console.WriteLine("Generation Number of Object is :"+GC.GetGeneration(MyObj2));
            GC.Collect(0);
            Console.WriteLine("Garage Colection in Gen 0 : "+GC.CollectionCount(0));
            Console.WriteLine("garbage Collection in Gen 1: "+GC.CollectionCount(1));


        }
    }
}
