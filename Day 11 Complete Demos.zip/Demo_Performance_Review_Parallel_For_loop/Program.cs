﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Performance_Review_Parallel_For_loop
{
    class Program
    {
        static long DoSomeIndependentTask()
        {
            long total = 0;
            for (int i = 0; i < 100000000; i++)
            {
                total += 1;
            }
            return total;
        }

        static void Main(string[] args)
        {
            DateTime StartTime = DateTime.Now;

            Console.WriteLine(@"For Lop Execution Start time At:{0}",StartTime);
            for (int i = 0; i < 10; i++)
            {
                long total = DoSomeIndependentTask();
                Console.WriteLine("{0} -{1}", i, total);
            }

            //Using Parallel For 
            //Parallel.For(0, 10, i =>
            //  {
            //      long total = DoSomeIndependentTask();
            //      Console.WriteLine("{0} -{1}", i, total);
            //  });

            DateTime EndTime = DateTime.Now;
            Console.WriteLine(@"For Loop End Time is : {0}",EndTime);
            Console.WriteLine($"For Loop End Time Is : {EndTime}");

            TimeSpan Span = EndTime - StartTime;
            int ms = (int)Span.TotalMilliseconds;
            Console.WriteLine(@"Total Time Taken  to executer Serial For Loop in Mili Seconds{0}",ms);
        }


    }
}
