﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Overriding_Polymorphism
{
    class Animal
    {
        //Base class methods overrides the derived class methods, when ththey share same name
        // So solve this limiattion we have to use Combination of Virtual- override keywords
        public virtual void Speak()
            //Using Virtual Gives us flexibilty of replacing the fucntion at runtime in child classes 
        {
            Console.WriteLine("Animal speaks using sound based communication.!!!");
        }
    }
}
