﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MathsLib;//name of My Class Lib becmones namespace


namespace Demo_Consuming_MathsLib_API
{
    class Program
    {
        static void Main(string[] args)
        {
            //What is the approach for calling functions of a class 

            //Step1 : Creating an Object of the class insiide Class Lib(dll)
            Class1 math = new Class1();

            //Step2: Calling methods from mathsLib
            float substract = math.Subtract(100, 45);
            float multiply = math.Multiply(25, 25);
            float divide = math.Divide(5, 2);
            float power = math.Power(9);

            //Displaying data 
            Console.WriteLine("This Project is using functions defined in MathsLib Class Lib....!!! ");
            Console.WriteLine(substract);
            Console.WriteLine(multiply);
            Console.WriteLine(divide);
            Console.WriteLine(power);

        }
    }
}
