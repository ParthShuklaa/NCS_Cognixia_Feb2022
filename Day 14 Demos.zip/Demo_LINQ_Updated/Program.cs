﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_LINQ_Updated
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("LINQ - Language Integrated Query");
            //Query Expression are written in a Declaritive query syntax
            //How many Hours are left for today?
            //how Many Demos we have completed todays ?
            //from variablename in Collections select variable name 
            //select * from Database (* means All) 

            int[] scores = { 99, 98, 91, 94, 100 };//Array with int values


            //Select  all the values where value is > 95
            // Define a Query Expression 
            IEnumerable<int> scoreQuery =
                from score in scores
                where score > 95
                select score;

            //Execute the Query Expression
            foreach (var item in scoreQuery)
            {
                Console.WriteLine(item + " ");
            }
        }
    }
}
