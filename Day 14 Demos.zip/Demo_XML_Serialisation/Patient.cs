﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_XML_Serialisation
{
    //Creating a Class that we need to serialize
    public class Patient
    {
        public int ID { get; set; }
        public string FirstName { get; set; }
        public string Lastname { get; set; }
        public DateTime Birthday { get; set; }
        public int RoomNo { get; set; }
    }
}
