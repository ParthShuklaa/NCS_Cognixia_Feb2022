﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Demo_XML_Serialisation
{
    class Program : Patient
    {
        static void Main(string[] args)
        {
            //Step2: Creating an Object of the Class
            Console.WriteLine("XML serialization : We Will transform Public Fields and property values of an ibject into a XML class" );
            var patient = new Patient()//patient is an Object of class Patient
            {
                ID = 101,
                FirstName = "Ricky",
                Lastname = "Pointing",
                Birthday = new DateTime(1980, 12, 30),
                RoomNo = 420
            };

            //Step3: Creating an XML Serializer Class pointing towards patirnt Patient class 
            var serializer = new XmlSerializer(typeof(Patient));

            //Defining a serialize method to transform  Object  Into XML
            using (var writer = new StreamWriter("patient.xml"))
            {
                serializer.Serialize(writer, patient);
            }



        }
    }
}
