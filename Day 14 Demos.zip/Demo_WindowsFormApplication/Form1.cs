﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demo_WindowsFormApplication
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //This Fucntion/Event Will be called when someone will click the button
            label1.Text = "Welcome to C# Way of Creating GUI Applications..!!!";
            label1.BorderStyle = BorderStyle.FixedSingle;

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //This Method will be called when form is loaded
            label1.Text = "here message will come after clicking the button";
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //Never Delete Unwanted Events methods
        }
    }
}
