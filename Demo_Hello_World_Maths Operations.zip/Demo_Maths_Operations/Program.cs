﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Maths_Operations
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Demonstrating Maths package inbuilt functions");
            Console.WriteLine(Math.Round(99.999));
            Console.WriteLine(Math.Abs(-25.6));
            Console.WriteLine(Math.Sqrt(9));
            

        }
    }
}
