﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Hello_World
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.Write("i am Feeling Lucky...."); ctrl +c for short cut 
            //Console.WriteLine("Enter your name ...?");
            //string username = Console.ReadLine();
            //Console.WriteLine("Username is :"+username);

            //Console.WriteLine("Enter Your Age");
            //int age = Convert.ToInt32( Console.ReadLine());
            //if (age > 18)
            //{
            //    Console.WriteLine("You can Vote");

            //}
            //else
            //{
            //    Console.WriteLine("Watch Cartoon ...!!!");
            //}


            //int myInt = 9;
            //double myDouble = myInt;
            //Console.WriteLine(myInt);
            //Console.WriteLine(myDouble);

            //Console.WriteLine("Your age is: "+age);



            /* This is a  Multiline comment
             * Types of variable  in C#
             * int - 
             * double
             * float
             * Char
             * String
             * Bool
             */


            int x = 5;
            int y = 25;
            //Console.WriteLine(!(x>3 && x<10));
            Console.WriteLine(x/y);
            Console.WriteLine(x%y);
            Console.WriteLine(x+y);
            Console.ReadKey();

        }
    }
}
