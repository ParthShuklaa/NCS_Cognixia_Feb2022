﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Abstraction
{
    class Cat:Animal,IAnimal
    {
        public override void AnimalSound()
        {
            Console.WriteLine("meow meow......");
           // throw new NotImplementedException();
        }

        public void kids()
        {
            Console.WriteLine("Cat kids are kitten");
            //throw new NotImplementedException();
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Cat persianCat = new Cat();//Creating an Object of Cat Class
            persianCat.AnimalSound();//Calling method of child class
            persianCat.sleep();
            persianCat.kids();

            // Animal myCat = new Animal(); Object of Abstract class can not created 
            Animal MyCat = new Cat();//Refrence of Parent class can be created 
            MyCat.sleep();

            IAnimal kitten = new Cat();
            kitten.kids();//Calling Kids function from cat class using ref of IAnimal Interface
        }
    }
}
