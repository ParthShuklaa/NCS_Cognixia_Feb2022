﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Exceptional_handling
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(" Exception handling in C# with Multiple catch block");
            try
            {
                int[] myNumber = { 1, 2, 3, 4 };
                Console.WriteLine(myNumber[1] / 1);

            }
            catch (IndexOutOfRangeException e)//here we are chcking for IndexoutofRange Exception
            {
                Console.WriteLine(e.GetType());//Displaying Message related to type of exception

            }
            catch (DivideByZeroException e1)//We are checking for Divide by Zero Exception
            {
                Console.WriteLine(e1.GetType());//Displaying Message related to type of exception
            }
            finally
            {
                Console.WriteLine("Thanks for testing the demo for exceptions..");
            }

            UserdefineException exp1 = new UserdefineException();
            exp1.CheckUserAge(15);
        }
    }
}
