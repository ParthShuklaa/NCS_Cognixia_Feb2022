﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Exceptional_handling
{
    class UserdefineException
    {
        public void CheckUserAge(int age)
        {
            if (age<14)
            {
                throw new Exception("Access Denied - As age of the user falls in minor category..!!");
                //throws an exception depending upon userdefine condition
            }
            else
            {
                Console.WriteLine("Access granted - You are old enough to login.!!!");
            }
        }
    }
}
