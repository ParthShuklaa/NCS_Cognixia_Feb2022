﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Structure_Implementation
{
    struct MyBooks
    {// Defining a structure 
        public string title;
        public string author;
        public string subject;
        public int book_id;

        public void getvalues(string t, string a, string s, int id)
        {
            title = t;
            author = a;
            subject = s;
            book_id = id;
        }
        public void Display()
            {
            Console.WriteLine("Book title :{0}", title);
            Console.WriteLine("Book Author : {0}", author);
            Console.WriteLine("Book Subject :{0}", subject);
            Console.WriteLine("Book Id is :{0}", book_id);
        }

    };
    class Program
    {
        static void Main(string[] args)
        {
            //Creating an Object of Structure 
            MyBooks book1;
            MyBooks book2 = new MyBooks();//Only applicable in C#'s Structure

            //providing specifications to objects
            book1.title = "Angels and Demons";
            book1.author = "Dan Brown";
            book1.subject = "Fiction";
            book1.book_id = 123;

            //Printing Book1 details 
            Console.WriteLine("Book 1 title :{0}",book1.title);
            Console.WriteLine("Book1 Author : {0}",book1.author);
            Console.WriteLine("Book1 Subject :{0}", book1.subject);
            Console.WriteLine("Book1 Id is :{0}",book1.book_id);

            book2.getvalues("Complete Reference for C# programing ", "Herbert Shildt", " Programming", 1232);

            book2.Display();
            


        }
    }
}
