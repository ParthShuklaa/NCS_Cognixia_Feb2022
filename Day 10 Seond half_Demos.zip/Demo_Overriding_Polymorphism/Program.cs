﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Overriding_Polymorphism
{
    class Dog : Animal
    {
        public override void Speak()
        {
            Console.WriteLine("Dog Barks to communicate with owners");
        }
    }
    class Horse : Animal
    {
        public void Speak()
        {
            Console.WriteLine("Horse Whine to communicate with Owners");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            //Creating Object of Animal Class
            Animal tiger = new Animal();
            tiger.Speak();//Speak from Animal Class was called

            Dog bruno = new Dog();//Creating Object of Dog class
            bruno.Speak();//Speak from Dog class was called 

            Animal myDog = new Dog();
            myDog.Speak();//Speak from Animal Class will be called 

        }
    }
}
