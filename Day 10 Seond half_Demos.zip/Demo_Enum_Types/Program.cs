﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Enum_Types
{ class UI
    {

        //We can define enum inside class also 
        public enum color // Enumerations - Specifically listed Constants 
        {
            Red =1,
            Blue=2,
            Green=3
        }
    }
    class Program :UI
    {
        static void Main(string[] args)
        {
            int FrontColor = Convert.ToInt32(color.Blue);
            //We Can Return Month No by Selecting Month Name like Above
            Console.WriteLine(FrontColor);
            color BgColor = color.Red;
            Console.WriteLine(BgColor);

            switch (BgColor)
            {
                case UI.color.Red:
                    Console.WriteLine(  "Background is red");
                    break;
                case UI.color.Blue:
                    Console.WriteLine("BackGround is Blue Color");
                    break;
                case UI.color.Green:
                    Console.WriteLine("Background is green color");
                    break;
                default:
                    break;
            }
        }
    }
}
