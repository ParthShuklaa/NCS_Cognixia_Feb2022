﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Demo_Queue_Generic
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Generic and Non-Generic Queue Implemetation in C#");
            //Step 1: Creating an Object class Queue
            //Step 2: Adding Elements in it (ENQUEUE()) 
            //Step 3: Displaying Element 
            //Step 4: Deleting Element (DEQUEUE())

            Queue<string> ToDoList = new Queue<string>();

            ToDoList.Enqueue("1.Reading Google News");
            ToDoList.Enqueue("2.Mastering Microsoft .NET Framework");
            ToDoList.Enqueue("3.Practising SQL SERVER Queries");
           
            foreach (var item in ToDoList)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("Element removed is :{0}", ToDoList.Dequeue());
            Console.WriteLine(" Total To Do task remaining are :{0}",ToDoList.Count);
            Console.WriteLine(" Top most priority remaing is :{0}", ToDoList.Peek());
            /// Since there is no concept of index we cant implement for loop 

            
            //ToDoList.Clear();
            

            Console.WriteLine(" Total To Do task remaining are :{0}", ToDoList.Count);
            Console.WriteLine(" Top most priority remaing is :{0}", ToDoList.Peek());


            Console.WriteLine("Implemeting Non-Genric Version of Queue...");

            Queue Record = new Queue();
            Record.Enqueue("First Employee from HR Dept ");
            Record.Enqueue(true);
            Record.Enqueue(3.14);
            Record.Enqueue('Y');
            Record.Enqueue(101);

            foreach (var item in Record)
            {
                Console.WriteLine(item);
            }

            Record.Dequeue();
            Console.WriteLine("Total Element in Queue are : {0}",Record.Count);


        }
    }
}
