﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Dictionary
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Implementing Dictionary in C#");

            //Step1: Creating an Object 
            Dictionary<int, string> EmpRecord = new Dictionary<int, string>();
            //<Username,password> or <SessionID,Username> < Name,Banck A/C No> <CardNo,CVV no> ,<CardNo,OTP>

            //Adding Element into dictionary
            EmpRecord.Add(101, "Christano Ronaldo");
            EmpRecord.Add(102, "Lionel Messi");
            EmpRecord.Add(103, " Neymar");

            //Display element using foreachloop
            foreach (var item in EmpRecord)
            {
                Console.WriteLine( item.Key +"-->"+item.Value);
            }

            Console.WriteLine("Total Size of the Dictionary is {0}", EmpRecord.Count);
           


        }
    }
}
