﻿using System;
using System.Collections;//Need to Include this namespace for implementing Non-Generic Collection 
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Generic_Collection
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Non - Generic Collections in C# - Extension to Arrays ex  ");
            //Step 1: Creating an Arraylist - Similare to an Array except the fact its size increses dynamically 
            ArrayList myList = new ArrayList();
            int[] MyArray = new int[5]();
            MyArray.Length;

            //or 
            //var MyList = new ArrayList();
            //Step 2: Adding element in Array list 
            myList.Add(25);//Adding an integer 
            myList.Add("I am batman");//Adding a string
            myList.Add(true);//Adding Boolean
            myList.Add(3.43);//Adding Float
            myList.Add(null);//Adding null value - No value 
            myList.Add(true);//Adding Boolean
            myList.Add(3.43);//Adding Float
            myList.Add(null);//Adding null value - No value 
            myList.Add(null);//Adding null value - No value 
            myList.Add(null);//Adding null value - No value 
            //Displaying Elements of myList - ArrayList
            for (int i = 0; i < myList.Count; i++)
            {
                Console.WriteLine(myList[i]);
            }

            Console.WriteLine("Total no of Elements {0} and Capapcity of myList is: {1}",myList.Count, myList.Capacity);
            //Console.WriteLine(myList.Count);
        }
    }
}
