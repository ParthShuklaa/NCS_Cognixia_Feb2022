﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_HashTable
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Implementing Hashtable (Non-Genric Collection ");
            Hashtable password = new Hashtable();


        }
    }
}
