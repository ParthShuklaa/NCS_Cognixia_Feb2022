﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Non_generic_Stack
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Stack can be implemented in Generic and Non-Generic Collection" );
            //Step 1: Creating a Collection
            //Step 2: Adding Element
            //Step 3: Displaying Element 
            //Step 4: Removing Element 

            Console.WriteLine("Implementing Non-Generic Stack ");
            Stack myStack = new Stack();

            myStack.Push(3.14);
            myStack.Push("Where is Starbucks??");
            myStack.Push(true);
            myStack.Push('Y');
            myStack.Push(2.3f);


            foreach (var item in myStack)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("Displaying the Top of Stack {0}",myStack.Peek());
            Console.WriteLine("Counting No of Elements in MyStack{0} ",myStack.Count);
            Console.WriteLine("Searching for an element ie 2.3f in MyStack is {0}",myStack.Contains(2.3f));


            Console.WriteLine( "Removing Element from the top{0}", myStack.Pop());//popping element from the stack

            foreach (var item in myStack)//Displaying element after pop()
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("Searching for an element ie 2.3f in MyStack is {0}", myStack.Contains(2.3f));
            Console.WriteLine("Displaying the Top of Stack {0}", myStack.Peek());
            Console.WriteLine("Counting No of Elements in MyStack{0} ", myStack.Count);


            Stack<int> mynewstack = new Stack<int>();//Generic version of stack which can only store int data
            mynewstack.Push(101);
            mynewstack.Push("hello howdy");//Gives us compile error- as it is against the rule of genric declaration
          
        }
    }
}
