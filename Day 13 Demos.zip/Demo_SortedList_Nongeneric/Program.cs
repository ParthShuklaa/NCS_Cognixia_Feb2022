﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_SortedList_Nongeneric
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Genric Sorted List implementation in C#");
            SortedList<string, int> PlayerStats = new SortedList<string, int>();
            PlayerStats.Add("C.Ronaldo", 101);
            PlayerStats.Add("Ronaldhino", 201);
            PlayerStats.Add("Neymar", 150);
            PlayerStats.Add("Suniel Chetri", 110);
            PlayerStats.Add("kaka", 150);

            foreach (var item in PlayerStats)
            {
                Console.WriteLine(item);
            }

            PlayerStats.Remove("kaka");
            foreach (var item in PlayerStats)
            {
                Console.WriteLine(item);
            }
            PlayerStats.RemoveAt(1);
            Console.WriteLine("After Removing Element from 1st position" );
            foreach (var item in PlayerStats)
            {
                Console.WriteLine(item);
            }
        }
    }
}
